#include <iostream>
#include "StringUtil.h"
#include <ctype.h>
using namespace std;
#include <fstream>

int main()
{
	/*fstream cout;
	cout.open("file.txt", ios::app);

	if (cout.is_open())
	{
		cout << "";
	}
	else
	{
		cout << "We fucked up" << endl;
		return 1;
	}*/

	char array[] = "hawaiian hamburger";
	StringUtil String1 = array;
	

	cout << "Length function (should be 18) " << String1.Length() << endl;
	cout << "Length Test: ";
	if (String1.Length() == 18) 
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "CharacterAt function at the second index (should be a) " << String1.CharacterAt(1) << endl;
	cout << "CharacterAt Test: ";
	if (String1.CharacterAt(1) == 'a')
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "EqualTo function comparing if char array is equal to cheeseburger (should be false) " << String1.EqualTo("cheeseburger") << endl;
	cout << "EqualTo Test: ";
	if (! String1.EqualTo("cheeseburger"))
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "Append function (should be hawaiian hamburgers) " << String1.Append("s") << endl;
	cout << "Append Test: ";
	if (String1 == "hawaiian hamburgers")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "Prepend function (should be not a hawaiian hamburgers) " << String1.Prepend("not a ") << endl;
	cout << "Prepend Test: ";
	if (String1 == "not a hawaiian hamburgers")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "C String function  (should return current string) " << String1.CStr() << endl;
	cout << "CStr Test: ";
	if (String1 == "not a hawaiian hamburgers")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "ToUpper function (should make everything uppercase) " << String1.ToUpper() << endl;
	cout << "ToUpper Test: ";
	if (String1 == "NOT A HAWAIIAN HAMBURGERS")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "ToLower function (should make everything lowercase) " << String1.ToLower() << endl;
	cout << "ToLower Test: ";
	if (String1 == "not a hawaiian hamburgers")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "Find function (should find ham from index 0) " << String1.Find("ham") << endl;
	cout << "Find Test: ";
	if (String1.Find("ham") == 15)
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "Find (from index) function (should find ham from index 3) " << String1.Find(3, "ham") << endl;
	cout << "Find (from index) Test: ";
	if (String1.Find(3, "ham") == 15)
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "Replace function (should replace ham with badham) " << String1.Replace("ham", "badham") << endl;
	cout << "Replace Test: ";
	if (String1 == "not a hawaiian badhamburgers")
	{
		cout << "Passed" << endl;
	}
	else cout << "Failed" << endl;

	cout << "ReadFromConsole function (should take input fron console and output it) " << String1.ReadFromConsole() << endl;
	cout << "ReadFromConsole Test: ";
	cout << "Passed" << endl;

	cout << "WriteToConsole function (should output current word stored; should be same as readfromconsole) " << String1.WriteToConsole() << endl;
	cout << "WriteToConsole Test: ";
	cout << "Passed" << endl;


	if (String1 == "hello")
	{
		cout << "string is equal to inputted string (==)" << endl;
	}
	else
	{
		cout << "string is not equal to inputted string (==)" << endl;
	}

	if (String1 != "hello")
	{
		cout << "string is not equal to inputted string (!= operator)" << endl;
	}
	else
	{
		cout << "string is equal to inputted string (!= operator)" << endl;
	
	}

	if (String1 < "hello")
	{
		cout << "string is less than inputted string (< operator)" << endl;
	}
	else
	{
		cout << "string is more than inputted string (< operator)" << endl;
	}

	if (String1 > "hello")
	{
		cout << "string is more than inputted string (>)" << endl;
	}
	else
	{
		cout << "string is less than inputted string (> operator)" << endl;
	}

	cout << String1[2] << " is the third character ([] operator)" << endl;

	char temparray[] = "\0";
	String1 = temparray;
	cout << String1.CStr() << endl;
	
	//Date/Time code
	struct tm newtime;
	time_t now = time(0);
	localtime_s(&newtime, &now);
	int sec = newtime.tm_sec;
	int min = newtime.tm_min;
	int hour = newtime.tm_hour;
	int day = newtime.tm_mday;
	int month = 1 + newtime.tm_mon;
	int year = newtime.tm_year;

	cout << "The time is: " << hour << ";" << min << " and " << sec << " seconds.";
	cout << "The date is: " << day << "/" << month << "/" << year + 1900 << endl;
}